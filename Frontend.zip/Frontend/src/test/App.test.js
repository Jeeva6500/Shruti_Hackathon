import { render, screen } from '@testing-library/react';
import * as React from 'react';
import '@testing-library/jest-dom/extend-expect';
import Register from '../Components/register/Register';

describe('Testing Register component', () => {
  test('Demo test', () => { console.log('Test executed'); })

    test('section is not in register', () => {
      render(<Register />)
      const sectionElem = screen.queryByRole('section', { name: 'section' })
      expect(sectionElem).not.toBeInTheDocument()
    })
  
    test('should have button in register', () => {
      render(<Register />)
      const buttonElem = screen.getByRole('button', { name: 'Sign Up' })
      expect(buttonElem).toBeInTheDocument()
    })
    
  
    test('should have container', () => {
      render(<Register />)
      const divElement = screen.getByTestId('container')
      expect(divElement).toBeInTheDocument()
    })
  
  
  })
  export default Register;
  