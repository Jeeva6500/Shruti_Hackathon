import React from 'react'
import './Footer.css';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import MobileScreenShareIcon from '@mui/icons-material/MobileScreenShare';
import HelpIcon from '@mui/icons-material/Help';
import FacebookOutlinedIcon from '@mui/icons-material/FacebookOutlined';
import TwitterIcon from '@mui/icons-material/Twitter';
import RssFeedRoundedIcon from '@mui/icons-material/RssFeedRounded';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import './Footer.css';
import { Link } from 'react-router-dom';
import { useNavigate } from "react-router-dom";



export default function Footer() {
    return (
       

   
        <div>
            <footer className="footer-area footer--light">
                <div className="footer-big">
                    <div className="container">
                        <div className='row'>
                            <div className="col-md-4 col-sm-4">
                                <div className='footer-widget footer-menu footer-menu--1'>
                                    <HelpIcon sx={{ fontSize: "45px", color: "#fff" }} />
                                    <span className='hr3'>Support center</span>
                                </div>
                            </div>
                            <div className="col-md-4 col-sm-4">
                                <div className='footer-widget footer-menu footer-menu--1'>
                                    <LocationOnIcon sx={{ fontSize: "45px", color: "#fff" }} />
                                    <span className='hr3'>Find a branch</span>
                                </div>
                            </div>
                            <div className="col-md-4 col-sm-4">
                                <div className='footer-widget footer-menu footer-menu--1'>
                                    <MobileScreenShareIcon sx={{ fontSize: "45px", color: "#fff" }} />
                                    <span className='hr3'>Get the NatWest app</span>
                                </div>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-md-4 col-sm-4">
                                <div className="footer-widget">
                                    <div className="footer-menu footer-menu--1">
                                        <h4 className="footer-widget-title">Products</h4>
                                        <hr className='hr1' />
                                        <ul>
                                            <li className="footerahover">
                                                <a href="#">Bank Accounts</a>
                                            </li>
                                            <li className="footerahover">
                                                <a href="#">Savings</a>
                                            </li>
                                            <li className="footerahover">
                                                <a href="#">Investments</a>
                                            </li>
                                            <li className="footerahover">
                                                <a href="#">Credit cards</a>
                                            </li>
                                            <li className="footerahover">
                                                <a href="#">Buy now pay later</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-4 col-sm-4">
                                <div className="footer-widget">
                                    <div className="footer-menu">
                                        <h4 className="footer-widget-title">Life moments</h4>
                                        <hr className='hr1' />
                                        <ul>
                                            <li className="footerahover">
                                                <a href="">View all life moments</a>
                                            </li>
                                            <li className="footerahover">
                                                <a href="#">Managing your money</a>
                                            </li>
                                            <li className="footerahover">
                                                <a href="#">Struggling financially</a>
                                            </li>
                                            <li className="footerahover">
                                                <a href="#">Bereavement</a>
                                            </li>
                                            <li className="footerahover">
                                                <a href="#">Financial health check</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-4 col-sm-4">
                                <div className="footer-widget">
                                    <div className="footer-menu no-padding">
                                        <h4 className="footer-widget-title">Help Support</h4>
                                        <hr className='hr1' />
                                        <ul>
                                            <li className="footerahover">
                                                <a href="#">Support</a>
                                            </li>
                                            <li className="footerahover">
                                                <a href="#">Security</a>
                                            </li>
                                            <li className="footerahover">
                                                <a href="#">Service status</a>
                                            </li>
                                            <li className="footerahover">
                                                <a href="#">Natwest app</a>
                                            </li>
                                            <li className="footerahover">
                                                <a href="#">Online Banking</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='container'>
                        <div className='row'>
                            <hr className='hr2' />
                            <div className='col-4'>
                                <h6>Privacy & Cookies</h6>
                                <h6>Modern Slavery Act</h6>
                            </div>
                            <div className='col-3'>
                                <h6>Website T&Cs</h6>
                            </div>
                          
                            <div className='col-4'>
                                <h6>Careers</h6>
                            </div>
                            <div className='col-1'>
                                <h6>Site Map</h6>
                            </div>
                        </div>
                        <div className='row'>
                            <FacebookOutlinedIcon sx={{ fontSize: "60px", color: "#fff" }} />
                            <TwitterIcon sx={{ fontSize: "60px", color: "#fff" }} />
                            <RssFeedRoundedIcon sx={{ fontSize: "60px", color: "#fff" }} />
                            <LinkedInIcon sx={{ fontSize: "60px", color: "#fff" }} />
                            <p>Copyright © National Westminster Bank plc 2022. Registered office: 250 Bishopsgate, London, EC2M 4AA.</p>
                        </div>
                    </div>
                </div>
                <div className="col-md-2 col-sm-4">
                </div>
            </footer>
        </div>
       
    )
}

