import { TextField } from '@mui/material'
import React from 'react'
import './Header.css'
import logo from './logo.png'
import SearchIcon from '@mui/icons-material/Search';
import { Link, useNavigate } from 'react-router-dom'


export default function Header() {
  const username = (sessionStorage.getItem('username'));

  const navigate = useNavigate();
  function logout() {

    sessionStorage.removeItem('mytoken');
    navigate("/login")
  }
  return (
    <div>

      <div className="head11">
        <ul className="nav nav-tabs ">
          <li className="nav-item">
            <a className="nav-link head22" aria-current="page">Personal</a>
          </li>
          <li className="nav-item ">
            <a className="nav-link head22">Premier</a>
          </li>
          <li className="nav-item">
            <a class="nav-link head22">Business</a>
          </li>
          <li className="nav-item">
            <a className="nav-link head22 ">Corporates & Institutions</a>
          </li>
        </ul>
      </div>

      <nav className="navbar navbar-expand-lg bgcol" >
        <div className="container-fluid">
          <img className='ms-3 ' style={{ width: "120px", height: "22px" }} src={logo} />
          <div className="collapse navbar-collapse " id="navbarSupportedContent">
            <ul className="navbar-nav me-auto mb-2 mb-lg-0 ms-5">
              <li className="nav-item nav-item1">
                <Link className="nav-link  text-primary1 me-2" aria-current="page" to="/">Home</Link>
              </li>
              <li className="nav-item nav-item1">
                <Link className="nav-link  text-primary1 me-2" aria-current="page" to="/natpay">NatPay</Link>
              </li>
              {!sessionStorage.getItem('mytoken') ?
                <>
                  <li className="nav-item nav-item1">
                    <Link className="nav-link text-primary1 me-2" aria-current="page" to="/contact">Contact Us</Link>
                  </li>

                  <li className="nav-item nav-item1">
                    <Link className="nav-link text-primary1 me-2" aria-current="page" to="/login">Login</Link>
                  </li>
                  <li className="nav-item nav-item1">
                    <Link className="nav-link text-primary1 me-2" aria-current="page" to="/register">Join Us</Link>
                  </li>

                </>
                : null}
              {sessionStorage.getItem('mytoken') ?
                <>
                  <li className="nav-item nav-item1">
                    <Link className="nav-link text-primary1 me-2" aria-current="page" to="/dashboard">Dashboard</Link>
                  </li>
                  <li className="nav-item nav-item1">
                    <a className="nav-link text-primary1 me-2" aria-current="page" href="#">Redeem Points</a>
                  </li>
                </>
                : null}
            </ul>
            {sessionStorage.getItem('mytoken') ?
              <div className="dropdown">
                <button className="btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false" style={{ color: 'white', backgroundColor: 'rgb(29,123,168)' }}>
                  {username}
                </button>
                <ul className="dropdown-menu">
                  <li><a className="dropdown-item" href="/" onClick={logout}>Logout</a></li>

                </ul>
              </div>
              : null
            }
            {!sessionStorage.getItem('mytoken') ?
              <>

                <form className="form-inline my-2 my-lg-0">
                  <SearchIcon sx={{ fontSize: "30px", color: "black" }} />
                  <TextField id="outlined-search" label="Search " type="search" />
                </form>
              </>
              : null}
          </div>
        </div>
      </nav>


    </div>
  )
}
