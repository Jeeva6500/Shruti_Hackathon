import { Button, Card, CardActionArea, CardContent, CardMedia, FormControl, Grid, InputLabel, TextField, Typography } from '@mui/material'
import React from 'react'
import './Dashboard.css'
import food from './food.jpg'
import medicine from './medicine.jpg'
import money from './money.jpg'
import movie from './movie.jpg'
import AccountBalanceWalletOutlinedIcon from '@mui/icons-material/AccountBalanceWalletOutlined';
import Box from '@mui/material/Box';
import MenuItem from '@mui/material/MenuItem';
import Select from '@mui/material/Select';
import Capture from './Capture.JPG'
import { Navigate } from 'react-router-dom'



export default function Dashboard() {
  const [age, setAge] = React.useState('');
  const username = sessionStorage.getItem('mytoken')

  const handleChange = (event) => {
    setAge(event.target.value);
  };
  if (sessionStorage.getItem('mytoken')) {
  return (
    <div className='dash'>
      <h1>
        Welcome! <br />
        What do you want to do today?
      </h1>
      <div className='container mt-4 mb-4'>
        <div className='row'>
          <div className='col-1'>
            <AccountBalanceWalletOutlinedIcon sx={{ fontSize: "85px", color: "#132F71" }} /> </div>
          <div className='col-3 pt-2'>
            <span className='span1'>£ 729.06 <br /> Your NatPay Balance </span>
          </div>
          <div className='col-4'>
            <form className="form-inline">
              <TextField id="outlined-search" label="Enter amount to be added in NatPay " type="search" sx={{ width: "110%" }} /><span className='add'>Have a Promo code?</span>
            </form>
          </div>
          <div className='col-3 ms-5 add'>
            <Button style={{ color: "#fff1e6", fontWeight: "600" }}
              variant="contained"
              fullWidth
              sx={{ minHeight: "60%", marginLeft: "2px" }}
            >
              Add Money
            </Button>
          </div>
        </div>
        <div className='row'>
          <div className='col-12'>
            <hr className='hrr' />
          </div>
        </div>
      </div>
      <div className='container'>
        <div className='row mb-3'>
          <div className='col-8'>
            <h4 className='exp'> Your Expenses (£) </h4>
          </div>
          <h4 className='col-4'>
            <Box sx={{ maxWidth: 320 }}>
              <FormControl fullWidth>
                <InputLabel id="demo-simple-select-label">Check Statement</InputLabel>
                <Select
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  value={age}
                  label="Check Statement"
                  onChange={handleChange}
                >
                  <MenuItem value={10}>3 months</MenuItem>
                  <MenuItem value={20}>6 months</MenuItem>
                  <MenuItem value={30}>12 months</MenuItem>
                </Select>
              </FormControl>
            </Box>
          </h4>
        </div>
        <div className='row'>
          <div className='col-12'>
            <hr className='hrrr' />
          </div>
        </div>
        <div>
          <img src={Capture} style={{width:'97%'}}/>
        </div>
        <div className='row'>
          <div className='col-12'>
            <hr className='hrr' />
          </div>
        </div>
      </div>


      <div className='grid1'>
        <Grid container spacing={2}>
          <Grid item xs={12} md={6}>
            <Card sx={{ maxWidth: 450 }}>
              <CardActionArea>
                <CardMedia
                  component="img"
                  height="200"
                  src={movie}
                />
                <CardContent>
                  <Typography gutterBottom variant="h5" component="div">
                    Book movie tickets with NatPay with ease and comfort!
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    NatPay offers booking latest movie tickets from the comfort
                    of your place in just a click! Use your NatWest Account for
                    direct booking and enjoy various discounts and offers.
                  </Typography>
                </CardContent>
              </CardActionArea>
            </Card>
          </Grid>
          <Grid item xs={12} md={6}>
            <Card sx={{ maxWidth: 450 }}>
              <CardActionArea>
                <CardMedia
                  component="img"
                  height="200"
                  src={medicine}
                />
                <CardContent>
                  <Typography gutterBottom variant="h5" component="div">
                    We saw you ordered some medicines last month, in need again?
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    No need to travel to the pharmacists for bringing medicines
                    homes or to your loved ones place, directly book it from
                    NatPay and we will deliver it at a rate less than the market price.
                  </Typography>
                </CardContent>
              </CardActionArea>
            </Card>
          </Grid>
          <Grid item xs={12} md={6}>
            <Card sx={{ maxWidth: 450 }}>
              <CardActionArea>
                <CardMedia
                  component="img"
                  height="200"
                  src={money}
                />
                <CardContent>
                  <Typography gutterBottom variant="h5" component="div">
                    Sending money to your spouse? Use NatPay
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    We make sure there are no technical error or bug while
                    you make a transfer to your loved ones. It's easy and
                    hastle free. Just enter the mobile number and send
                    it in a click with no worries. We will handle it.
                  </Typography>
                </CardContent>
              </CardActionArea>
            </Card>
          </Grid>
          <Grid item xs={12} md={6}>
            <Card sx={{ maxWidth: 450 }}>
              <CardActionArea>
                <CardMedia
                  component="img"
                  height="200"
                  src={food}
                />
                <CardContent>
                  <Typography gutterBottom variant="h5" component="div">
                    Craving for food and don't have time to visit the outlet?
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Anytime, anywhere. We have tied up with major outlets all
                    over UK. We provide hastle free service and offer various
                    discounts on order above a limited range. So, order now and
                    use these benefits.
                  </Typography>
                </CardContent>
              </CardActionArea>
            </Card>
          </Grid>
        </Grid>
      </div>
    </div>
  )
} else {
  return <Navigate to="/login" />
}
}
