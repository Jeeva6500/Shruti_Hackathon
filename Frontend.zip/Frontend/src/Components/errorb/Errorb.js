import React from 'react'
import './Errorb.css'

export default function Errorb() {
  return (
    <div className='container bg'>
    <div className='hite'>
    <h1> 404 Error Page</h1>
        <h2>
            OOPS.<br/>
            Even the things we love break sometimes.
        </h2>
    </div>

   
    </div>
  )
}

