import { Button, Card, CardActionArea, CardContent, CardMedia, Grid, Typography, } from '@mui/material'
import Rating from '@mui/material/Rating';
import StarIcon from '@mui/icons-material/Star';
import React from 'react'
import './Display.css'
import main2 from './main2.png'
import main3 from './main3.png'
import main4 from './main4.jpg'
import main5 from './main5.jpg'
import InfoIcon from '@mui/icons-material/Info';


export default function Display() {
  return (
    <div >
      <div className="mydisplay">
        <div className="box3 " >
          <h5 className='ms-2' ><InfoIcon sx={{ color: "black" }} />   'NatPay' - NatWest Payment Wallet! Visit the page for exciting offers and services now</h5>
        </div>
        <div className="box2 pb-4 pt-4 ps-3 px-3 mx-5" >
          <h1 className='ms-2' >Tomorrow begins today</h1>
          <h5 className='mt-3 mb-5 ms-2'>At NatWest we believe today is the most important day of the week.</h5>
          <Button variant="contained" size="large" >Find Out More</Button>
          <div>

          </div>
        </div>
      </div>
      <div className='pt-5 pb-4 display1' >
        <img src={main2} height={300} width={500}></img>
        <div className='display3 ms-5'>
          <h2 className='mb-4 heading1'>Year Ahead 2023</h2>
          <p className='ms-5'>Energy prices appear to hold most sway over the<br />

            economy and markets in 2023.<br />
            <br />

            In our series of articles and podcasts, we explore the<br />
            impact of energy markets across four major themes<br />
            that we believe will fundamentally drive the <br />outlook across .
            regions, sectors, and markets.<br /></p>
          <br /><div className='ms-5'>
            <Button variant="contained" size="large">
              Visit the year Ahead 2023 Hub
            </Button>
          </div>
        </div>
      </div>
      <div className='display4'>
        <div className='display5'>
          <h2>What's the deal with the latest <br />rally?</h2>
          <p>Sharpen your view with our insights and fixed income <br />analysis. Our rates strategists discuss the <br />biggest themes & events shaping the landscape.</p>
          <Rating
            name="text-feedback"
            value={4}
            readOnly
            precision={1}
            emptyIcon={<StarIcon style={{ opacity: 0.55 }} fontSize="inherit" />}
          />
        </div>
        <img src={main3} height={300} width={500} ></img>
      </div>
      <div className='division6'>
        <h1 className='mb-4 ms-4 heading1'>
          Client Stories</h1>
        <h5 className='mb-5 ms-4'>Read how we're helping businesses to thrive.</h5>
        <div>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Card sx={{ maxWidth: 450 }}>
                <CardActionArea>
                  <CardMedia
                    component="img"
                    height="200"
                    src={main4}
                  />
                  <CardContent>
                    <Typography gutterBottom variant="h5" component="div">
                      Diageo's $2 billion Senior Notes quench the thirst of investors
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Seeking to return to the US Dollar market for the first
                      time since April 2020, Diageo asked NatWest to support
                      the bond issuance as an Active Bookrunne
                    </Typography>
                  </CardContent>
                </CardActionArea>
              </Card>
            </Grid>
            <Grid item xs={12} md={6}>
              <Card sx={{ maxWidth: 450 }}>
                <CardActionArea>
                  <CardMedia
                    component="img"
                    height="200"
                    src={main5}
                  />
                  <CardContent>
                    <Typography gutterBottom variant="h5" component="div">
                      CADES issue 9th Social Bond
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      As part of its €40 billion issuance programme for 2022,
                      CADES asked NatWest to support the transaction of a 5-
                      year EUR Social Bond, as Joint Bookrunner.
                    </Typography>
                  </CardContent>
                </CardActionArea>
              </Card>
            </Grid>
          </Grid>
        </div>
      </div>
    </div>

  )
}