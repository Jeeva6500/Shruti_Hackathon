import React from 'react'
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import cont from './cont.jpg'
import './Contact.css'


export default function Contact() {
  return (
    <div className="container contactbg">
      <div className="row">
        <div className="col-8 offset-2 mb-5">
          <Card sx={{ height: "80vh", marginTop: "80px", border: "2px solid black" }}>
            <CardMedia
              component="img"
              alt=""
              height="300"
              src={cont}
            />
            <CardContent>
              <Typography gutterBottom variant="h5" component="div" color='#42145f'>
                Want to get in touch?
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Contact our team if you'd like to know more.
              </Typography>
            </CardContent>
            <CardActions>
      
              <Button style={
                { backgroundColor: "#132F71",
                 color: "#fff1e6", fontWeight: "600", borderRadius: "8px" ,}}>Call Us</Button>
      
              </CardActions>
          </Card>
        </div>
      </div>
    </div>

  );
}