import * as React from 'react';
import Avatar from '@mui/material/Avatar';
import Button from '@mui/material/Button';
import CssBaseline from '@mui/material/CssBaseline';
import TextField from '@mui/material/TextField';
import Box from '@mui/material/Box';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { useFormik } from 'formik'
import * as yup from 'yup'
import Grid from '@mui/material/Grid';
import './Register.css'
import BusinessCenterOutlinedIcon from '@mui/icons-material/BusinessCenterOutlined';
import { Alert, Snackbar } from '@mui/material';
import axios from 'axios';

const theme = createTheme();
export default function Register() {

  const [open1, setOpen1] = React.useState(false);
  const [err,setErr] = React.useState('');

  const [open, setOpen] = React.useState(false);

  const handleClick = () => { }

  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    setOpen(false);
    setOpen1(false);

  };
  const formik = useFormik({
    initialValues: {
      firstname: "",
      id: "",
      account: "",
      phone: "",
      address: "",
      password: "",
      confirm_password: ""
    },
    onSubmit: (values, action) => {

      action.resetForm();

      axios.post("http://localhost:8080/natpay/natpaycustomer/newcustomer",values,)
        .then(res=> {
          console.log(res);
          setOpen(true);
      })
        .catch(error => {setErr(error.response.data)
          setOpen1(true);})
        
    },
    validationSchema: yup.object().shape({
      firstname: yup.string()
        .matches(/^[a-z A-Z \.]{3,}$/, "Name is Invalid. It should be more than 2 characters.")
        .required("Name can not be left blank"),
      id: yup.string()
        .email("Email id is Invalid. It should be in proper format. Example - xyz@gmail.com")
        .required("Email id can not be left blank"),
      account: yup.string()
        .matches(/^[6-9][0-9]{8}$/, "Account number is Invalid. It should be atleast 9 digits and should start with 6, 7 , 8 or 9.")
        .required("Account Number can not be left blank"),
      phone: yup.string()
        .matches(/^[7-9][0-9]{9}$/, "Phone number is Invalid. It should have 10 digits and should start with 7, 8 or 9.")
        .required("Mobile Number can not be left blank"),
      address: yup.string()
        .max('20')
        .required("Address can not be left blank"),
      password: yup.string()
        .matches(/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/, "Password is Invalid. It should have minimum eight characters, at least one letter and one number.")
        .required("Password can not be left blank"),
      confirm_password: yup.string()
        .oneOf([yup.ref("password"), null], "Password and Confirm password should be same.")
        .required("Confirm Password can not be left blank"),
    })
  })

  return (
    <div data-testid='container'>
      <h1 className='registerhead pb-5 pt-5 px-2'>
        <BusinessCenterOutlinedIcon sx={{ fontSize: "50px", color: "white", marginRight: '10px' }} />
        GET STARTED
      </h1>
      <div className='mb-5 mt-3 container'>
        <ThemeProvider theme={theme} >
          <Container component="main" maxWidth="md" style={{ border: "2px solid #0d255b", borderRadius: "10px" }}>
            <CssBaseline />
            <Box
              sx={{
                marginTop: 10,
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
              }}
            >
              <Avatar sx={{ m: 1, bgcolor: '#132F71' }} style={{ marginTop: "-60px" }} >
                <LockOutlinedIcon />
              </Avatar>
              <Typography component="h1" variant="h5" style={{ color: "#42145f" }}>
                Join 'NatPay' - One single solution for every problem.
              </Typography>
              <Box component="form" onSubmit={formik.handleSubmit} noValidate sx={{ mt: 1 }}>
                <Grid container spacing={2}>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      onChange={formik.handleChange} onBlur={formik.handleBlur}
                      value={formik.values.firstname}
                      margin="normal"
                      required
                      fullWidth
                      id="firstname"
                      label="Name"
                      type="text"
                      name="firstname"
                      autoComplete="off"
                    />
                    {formik.errors.firstname && formik.touched.firstname ? <span className='text-danger'>{formik.errors.firstname}</span> : null}
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      onChange={formik.handleChange} onBlur={formik.handleBlur}
                      value={formik.values.id}
                      margin="normal"
                      required
                      fullWidth
                      id="id"
                      label="Email Address"
                      name="id"
                      type="id"
                      autoComplete="off"
                    />
                    {formik.errors.id && formik.touched.id ? <span className='text-danger'>{formik.errors.id}</span> : null}
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      onChange={formik.handleChange} onBlur={formik.handleBlur}
                      value={formik.values.account}
                      margin="normal"
                      required
                      fullWidth
                      id="account"
                      label="Account Number"
                      type="number"
                      name="account"
                      autoComplete="off"
                    />
                    {formik.errors.account && formik.touched.account ? <span className='text-danger'>{formik.errors.account}</span> : null}
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      onChange={formik.handleChange} onBlur={formik.handleBlur}
                      value={formik.values.phone}
                      margin="normal"
                      required
                      fullWidth
                      id="phone"
                      type="number"
                      label="Mobile Number"
                      name="phone"
                      autoComplete="off"
                    />
                    {formik.errors.phone && formik.touched.phone ? <span className='text-danger'>{formik.errors.phone}</span> : null}
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      onChange={formik.handleChange} onBlur={formik.handleBlur}
                      value={formik.values.address}
                      margin="normal"
                      required
                      fullWidth
                      id="address"
                      label="Address"
                      name="address"
                      type="text"
                      autoComplete="off"
                    />
                    {formik.errors.address && formik.touched.address ? <span className='text-danger'>{formik.errors.address}</span> : null}
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      onChange={formik.handleChange} onBlur={formik.handleBlur}
                      value={formik.values.password}
                      margin="normal"
                      required
                      fullWidth
                      id="password"
                      label="Password"
                      name="password"
                      type="password"
                      autoComplete="off"
                    />
                    {formik.errors.password && formik.touched.password ? <span className='text-danger'>{formik.errors.password}</span> : null}
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      onChange={formik.handleChange} onBlur={formik.handleBlur}
                      value={formik.values.confirm_password}
                      margin="normal"
                      required
                      fullWidth
                      id="confirm_password"
                      label="Confirm Password"
                      type="password"
                      name="confirm_password"
                      autoComplete="off"
                    /></Grid>
                </Grid>
                {formik.errors.confirm_password && formik.touched.confirm_password ? <span className='text-danger'>{formik.errors.confirm_password}</span> : null}
                <Button style={{ backgroundColor: "#132F71", color: "#fff1e6", marginBottom: "50px", fontWeight: "600" }}
                  type="submit"
                  fullWidth
                  variant="contained"
                  onClick={handleClick}
                  sx={{ mt: 3, mb: 2 }}
                >
                  Sign Up
                </Button>
                <Snackbar anchorOrigin={{ vertical: 'top', horizontal: 'center' }} open={open} autoHideDuration={4000} onClose={handleClose}>
                  <Alert onClose={handleClose} severity="success" sx={{ width: '100%' }}>
                    Registration Successful!
                  </Alert>
                </Snackbar>
                <Snackbar anchorOrigin={{ vertical: 'top', horizontal: 'center' }} open={open1} autoHideDuration={4000} onClose={handleClose}>
                      <Alert onClose={handleClose} severity="error" sx={{ width: '100%' }}>{err}</Alert>
                    </Snackbar>
              </Box>
            </Box>
          </Container>
        </ThemeProvider>
      </div>
    </div>
  );
}