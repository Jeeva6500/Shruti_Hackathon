import * as React from 'react';
import Avatar from '@mui/material/Avatar';
import Button from '@mui/material/Button';
import CssBaseline from '@mui/material/CssBaseline';
import TextField from '@mui/material/TextField';
import Link from '@mui/material/Link';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { useFormik } from 'formik'
import * as yup from 'yup'
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import Stack from '@mui/material/Stack';
import Snackbar from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';
import illustration from './illustration.gif';
import './login.css';


const theme = createTheme();
const Alert = React.forwardRef(function Alert(props, ref) {
  return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

export default function Login() {
  const [open, setOpen] = React.useState(false);
  const [err,setErr] = React.useState('');
  const handleClick = () => { }
  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    setOpen(false);
  };
  const navigate = useNavigate();
  const formik = useFormik({
    initialValues: {
      id: "",
      password: "",
    },
    onSubmit: (values, action) => {

      action.resetForm();

      axios.post('http://localhost:8080/login', values)
      .then(res => {
        console.log(res);
        sessionStorage.setItem('mytoken', res.data.token);
        sessionStorage.setItem('username',res.data.username);
        navigate('/dashboard')
        
      })
      .catch(error => {setErr(error.response.data.message)
        setOpen(true)})
    },
    validationSchema: yup.object().shape({
      id: yup.string()

        .required("Email cannot be left blank"),
      password: yup.string()
        .required("Password cannot be left blank"),
    })
  })


  return (
    <div className=' container log'>
      <div className='row'>
        <div className='col-7'>
          <ThemeProvider theme={theme}>
            <Container component="main" maxWidth="xs" style={{ border: "2px solid #42145f", borderRadius: "15px", height: "500px", width: "35000px" }}>
              <CssBaseline />
              <Box
                sx={{
                  marginTop: 8,
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                }}
              >
                <Avatar sx={{ m: 1, bgcolor: '#132F71' }} style={{ marginTop: "-40px" }}>
                  <LockOutlinedIcon />
                </Avatar>
                <Typography component="h1" variant="h5" color='#42145f'>
                  Login Here
                </Typography>
                <Box component="form" onSubmit={formik.handleSubmit} noValidate sx={{ mt: 1 }}>
                  <TextField
                    onChange={formik.handleChange} onBlur={formik.handleBlur}
                    value={formik.values.id}
                    margin="normal"
                    required
                    fullWidth
                    id="id"
                    label="Email Address"
                    name="id"
                    autoComplete="off"

                  />
                  {formik.errors.id && formik.touched.id ? <span className='text-danger'>{formik.errors.id}</span> : null}
                  <TextField
                    onChange={formik.handleChange} onBlur={formik.handleBlur}
                    value={formik.values.password}
                    margin="normal"
                    required
                    fullWidth
                    name="password"
                    label="Password"
                    type="password"
                    id="password"
                    autoComplete="off"

                  />
                  {formik.errors.password && formik.touched.password ? <span className='text-danger'>{formik.errors.password}</span> : null}
                  <Stack spacing={2} sx={{ width: '100%' }}>

                    <Button style={{ backgroundColor: "#132F71", color: "#fff1e6", marginBottom: "50px", fontWeight: "600" }}
                      type="submit"
                      fullWidth
                      variant="contained"
                      onClick={handleClick}
                      sx={{ mt: 3, mb: 4 }}
                    >
                      Login
                    </Button>
                    <Snackbar anchorOrigin={{ vertical: 'top', horizontal: 'center' }} open={open} autoHideDuration={4000} onClose={handleClose}>
                      <Alert onClose={handleClose} severity="error" sx={{ width: '100%' }}>
                      {err}
                      </Alert>
                    </Snackbar>
                  </Stack>
                  <Grid container style={{ marginBottom: "40px" }}>
                    <Grid item xs>
                      <Link href="/register" variant="body2">
                        Forgot password?
                      </Link>
                    </Grid>
                    <Grid item>
                      <Link href="/register" variant="body2">
                        {"Don't have an account? Sign Up"}
                      </Link>
                    </Grid>
                  </Grid>
                </Box>
              </Box>

            </Container>
          </ThemeProvider>
        </div>
        <div className='col-4 '>
          <img src={illustration} height='500px' width={300} />
        </div>
      </div>
    </div>
  );
}