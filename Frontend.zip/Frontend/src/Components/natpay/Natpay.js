import React from 'react'
import './Natpay.css'
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import StepContent from '@mui/material/StepContent';
import Button from '@mui/material/Button';
import Paper from '@mui/material/Paper';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import Stepper from '@mui/material/Stepper';
import nat1 from './nat1.gif';
import stepper from './stepper.jpg';
import GetAppIcon from '@mui/icons-material/GetApp';


const steps = [
  {
    label: 'STEP 1',
    description: `Generate Your Payment Link,
           via API or Dashboard with free Reminders `,

  },
  {
    label: 'STEP 2',
    description: `Enter Customer Contact Details,
    Share link via SMS, Whatsapp, Email and more `,
  },
  {
    label: 'STEP 3',
    description: `Enjoy NatPay Services on your mobile and order movie tickets,
    medicines, food/beverages and use the NatPay vouchers and coupons for additional discounts.`,
  },
];


export default function VerticalLinearStepper() {
  const [activeStep, setActiveStep] = React.useState(0);

  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleReset = () => {
    setActiveStep(0);
  };



  return (
    <div className='container'>
      <div className='pay row'>
        <div className='myclass pt-5 col-6 px-5'>
          <h2 style={{ color: '#0d255b' }}>Get paid instantly with "NatPay"</h2>
          <hr className='hr5' />
          <h4 style={{ color: 'black' }}>
            Share payment link via an email, SMS, messenger,
            chatbot etc. and get paid immediately. Accepting
            payments from customers is now just a link away.
            Make easy payments with a click.
          </h4>
          <h5 className='mt-3'>Download the app now! <GetAppIcon sx={{ fontSize: "30px", color: "black" }} /> </h5>
        </div>
        <div className='myclass pt-5 col-6 px-5'>
          <img src={nat1} />
        </div>
      </div>
      <hr />
      <h2 className='h22'>3 Simple Steps To Accept Payment Via NatPay</h2>
      <div className='row'>
        <div className='col-6'>
          <img src={stepper} className='stepperimg' />
        </div>
        <div className=' col-5 mb-4'>
          <Box sx={{ maxWidth: 500 }} >
            <Stepper activeStep={activeStep} orientation="vertical">
              {steps.map((step, index) => (
                <Step key={step.label}>
                  <StepLabel
                    optional={
                      index === 2 ? (
                        <Typography variant="caption">Accept Payments
                          Receive notifications in real time.</Typography>
                      ) : null
                    }
                  >
                    {step.label}
                  </StepLabel>
                  <StepContent>
                    <Typography>{step.description}</Typography>
                    <Box sx={{ mb: 2 }}>
                      <div>
                        <Button
                          variant="contained"
                          onClick={handleNext}
                          sx={{ mt: 1, mr: 1 }}
                        >
                          {index === steps.length - 1 ? 'Finish' : 'Continue'}
                        </Button>
                        <Button
                          disabled={index === 0}
                          onClick={handleBack}
                          sx={{ mt: 1, mr: 1 }}
                        >
                          Back
                        </Button>
                      </div>
                    </Box>
                  </StepContent>
                </Step>
              ))}
            </Stepper>
            {activeStep === steps.length && (
              <Paper square elevation={0} sx={{ p: 3 }}>
                <Typography>All steps completed - you&apos;re finished</Typography>
                <Button onClick={handleReset} sx={{ mt: 1, mr: 1 }}>
                  Reset
                </Button>
              </Paper>
            )}
          </Box>
        </div>
        <hr />
        <div className='lasttag'>
          <h1>
            Solutions. Service. Stability.
          </h1>
          <h5>
            Experience the NatPay difference. Join us today for premium benefits.
          </h5>
        </div>

      </div>
    </div>
  )
}
