
import { ErrorBoundary } from 'react-error-boundary';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './App.css';
import { Suspense } from 'react';
import React from 'react';
import Errorb from './Components/errorb/Errorb';
const Dashboard = React.lazy(()=> import('./Components/dashboard/Dashboard'))
const Display = React.lazy(()=> import('./Components/display/Display'))
const Footer = React.lazy(()=> import('./Components/footer/Footer'))
const Header = React.lazy(()=> import('./Components/header/Header'))
const Login = React.lazy(()=> import('./Components/login/Login'))
const Natpay = React.lazy(()=> import('./Components/natpay/Natpay'))
const Register = React.lazy(()=> import('./Components/register/Register'))
const Contact = React.lazy(()=> import('./Components/contact/Contact'))


function App() {

  return (
    <div>
     <BrowserRouter>
       <Header/>
       <ErrorBoundary FallbackComponent= {Errorb}>
        <Suspense fallback={<div><h5 className='alert alert-danger text-center'>Your content is loading...</h5></div>}>
        <Routes>
          <Route path='/' element = {<Display/>} />
          <Route path='/natpay' element = {<Natpay/>} />
          <Route path='/login' element = {<Login/>} />
          <Route path='/register' element = {<Register/>} />
          <Route path='/dashboard' element = {<Dashboard/>} />
          <Route path='/contact' element = {<Contact/>} />
        </Routes>
        </Suspense>
        </ErrorBoundary>
      </BrowserRouter>
    <Footer/>
    </div>
  );
}

export default App;
