package com.natwest.registerapi.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(value=CustomerAlreadyExist.class)
	public ResponseEntity<String> UserAlreadyExist(){
		return new ResponseEntity<String>("Email-id is already registered.Sign up with another email.", HttpStatus.NOT_FOUND);
		
	}

}
