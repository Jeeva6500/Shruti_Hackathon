package com.natwest.registerapi.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.LinkedList;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.natwest.registerapi.model.CustomerDetails;
import com.natwest.registerapi.service.CustomerService;

@WebMvcTest
public class CustomerControllerTests {
	
	@Autowired
	MockMvc mockMvc;
	
	@MockBean
	CustomerService customerService;
	
	ObjectMapper mapper = new ObjectMapper();
	ObjectWriter writer = mapper.writer();
	
	List<CustomerDetails> customerList = null;

	@BeforeEach
	void setUp() throws Exception {
	customerList = new LinkedList<>();
	customerList.add(new CustomerDetails("rishabh@gmail.com","Rishi","987987987","9879875672","Delhi","Rish1212"));
	customerList.add(new CustomerDetails("shubham@gmail.com","Shubh","878787879","7838990987","London","Shubh2929"));
	customerList.add(new CustomerDetails("nikita@gmail.com","Nikiss","989898982","8767000012","Mumbai","Lily8767"));
	customerList.add(new CustomerDetails("ankita@gmail.com","Ankiii","789789789","9999765632","Banglore","Ankita29"));
	}

    @AfterEach
    void tearDown() throws Exception {
    	customerList=null;}
       	  
    @Test
    void testAddCustomer() throws Exception {
	CustomerDetails ccc = new CustomerDetails("Neha@gmail.com","Neha","987654321","9876543210","New Delhi","Pass1212");
	
	when(customerService.addCustomer(ccc)).thenReturn(ccc);
	
	String content = writer.writeValueAsString(ccc);
	mockMvc.perform(post("/natpay/natpaycustomer/newcustomer")
			.contentType(MediaType.APPLICATION_JSON)
			.content(content))
	.andExpect(status().is(201));

}
}




