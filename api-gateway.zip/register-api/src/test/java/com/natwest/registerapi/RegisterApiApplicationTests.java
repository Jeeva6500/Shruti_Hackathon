package com.natwest.registerapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegisterApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
