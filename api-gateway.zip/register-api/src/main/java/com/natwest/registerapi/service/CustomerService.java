package com.natwest.registerapi.service;

import java.util.List;

import com.natwest.registerapi.exception.CustomerAlreadyExist;
import com.natwest.registerapi.model.CustomerDetails;

public interface CustomerService {

	public CustomerDetails addCustomer(CustomerDetails Customer) throws CustomerAlreadyExist;
	public List<CustomerDetails> getAllCustomers();


}
