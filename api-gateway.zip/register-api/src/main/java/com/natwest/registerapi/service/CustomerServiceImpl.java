package com.natwest.registerapi.service;

import java.util.List;
import java.util.Optional;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.natwest.registerapi.dao.CustomerRepository;
import com.natwest.registerapi.exception.CustomerAlreadyExist;
import com.natwest.registerapi.model.CustomerDetails;

@Service
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	private CustomerRepository customerRepo;

	@Override
	public CustomerDetails addCustomer(CustomerDetails Customer) throws CustomerAlreadyExist {
		BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
        String encryptPassword = bCryptPasswordEncoder.encode(Customer.getPassword());

		
		Optional<CustomerDetails> mess = customerRepo.findById(Customer.getId());
		if(mess.isPresent()) {
			throw new CustomerAlreadyExist();
		}
		Customer.setPassword(encryptPassword);
		CustomerDetails CustomerDetails = customerRepo.save(Customer) ;
	        return CustomerDetails;
	}
		
		@Override
		public List<CustomerDetails> getAllCustomers() {
			return customerRepo.findAll();
		}

}	

	
