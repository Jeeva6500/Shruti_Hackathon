package com.natwest.registerapi.exception;

public class CustomerAlreadyExist extends Exception {
	
	public CustomerAlreadyExist(String message) {
		super(message);
	}
	
	public CustomerAlreadyExist() {
		
	}


}
