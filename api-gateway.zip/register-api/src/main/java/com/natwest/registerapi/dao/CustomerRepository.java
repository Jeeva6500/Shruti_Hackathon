package com.natwest.registerapi.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.natwest.registerapi.model.CustomerDetails;

@Repository
public interface CustomerRepository extends JpaRepository<CustomerDetails, String> {


}
