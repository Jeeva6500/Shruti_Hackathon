package com.natwest.Loginapi.service;

import java.util.Optional;

import com.natwest.Loginapi.model.CustomerDetails;

public interface CustomerService {
	
	public Optional<CustomerDetails> findById(String id);

	}


