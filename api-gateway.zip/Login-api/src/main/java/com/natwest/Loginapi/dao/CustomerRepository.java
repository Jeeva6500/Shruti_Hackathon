package com.natwest.Loginapi.dao;

import org.springframework.data.repository.CrudRepository;

import com.natwest.Loginapi.model.CustomerDetails;

public interface CustomerRepository extends CrudRepository<CustomerDetails, String>  {
	public CustomerDetails findByIdAndPassword(String id, String password);

	
}
