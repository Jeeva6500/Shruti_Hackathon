package com.natwest.Loginapi.model;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


	
	@Entity
	@Table(name= "customerDetails")
	public class CustomerDetails {
		
	@Id	
	private String id;
	private String firstname;
	private String account;
	private String phone;
	private String address;
	private String password;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public CustomerDetails(String id, String firstname, String account, String phone, String address, String password) {
		super();
		this.id = id;
		this.firstname = firstname;
		this.account = account;
		this.phone = phone;
		this.address = address;
		this.password = password;
	}
	public CustomerDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

}
