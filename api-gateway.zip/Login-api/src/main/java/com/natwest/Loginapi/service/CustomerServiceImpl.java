package com.natwest.Loginapi.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.natwest.Loginapi.dao.CustomerRepository;
import com.natwest.Loginapi.model.CustomerDetails;

@Service
public class CustomerServiceImpl implements CustomerService {
	
	
	@Autowired
	private CustomerRepository customerRepo;

	@Override
	public Optional<CustomerDetails> findById(String id) {
		// TODO Auto-generated method stub
		return customerRepo.findById(id);
	}
	
	


	
}
